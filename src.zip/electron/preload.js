// Preload script that runs before React gets loaded in Electron.
window.addEventListener('DOMContentLoaded', () => {
    console.log('Electron preloaded')
  })
  